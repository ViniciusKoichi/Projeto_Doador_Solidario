window.addEventListener('scroll', onScroll);

onScroll()

function onScroll() {
    showNavOnScroll()
}

function showNavOnScroll() {
    if (scrollY > 0) {
        nav_bar.classList.add('scroll');
    } else {
        nav_bar.classList.remove('scroll');
    }
}

