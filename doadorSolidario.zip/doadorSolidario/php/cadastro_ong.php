<?php
require_once("configuracao.php");
require_once("funcoes_diversas.php");
require_once("BancoDados.php");

error_reporting(E_ERROR | E_PARSE);
session_name('System_A');
session_start();

$nome = $_REQUEST["Nome_ong"];
$email = $_REQUEST["Email"];
$senha = $_REQUEST["Senha_Acesso"];
$endereco = $_REQUEST["Endereco"];
$numero = $_REQUEST["Numero"];
$bairro = $_REQUEST["Bairro"];
$cidade = $_REQUEST["Cidade"];
$cep = $_REQUEST["cep"];
$erroDados = FALSE;
$mensagemErro = "";

if(trim($nome) == "" && trim($email) == "" && trim($senha) == "") {

} else {
        if(trim($nome) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Nome Obrigatório...</h3>";
    }

    if(trim($email) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>E-mail Obrigatório...</h3>";
    }

    if(trim($senha) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Senha Obrigatória...</h3>";
    }

    if(trim($endereco) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Enderço Obrigatório...</h3>";
    }

    if(trim($numero) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Número Obrigatório...</h3>";
    }

    if(trim($bairro) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Bairro Obrigatório...</h3>";
    }

    if(trim($cidade) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Cidade Obrigatória...</h3>";
    }

    if(trim($cep) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Cep Obrigatório...</h3>";
    }

    if(!$erroDados) {
        $conexao_bd = new BancoDados($servidorMySQL);
        if(!$conexao_bd->abrirConexao()) {
            echo "<h3>Erro na conexão com o banco de dados!<br/>" . $conexao_bd->getMensagemErro() . "</h3>";
        } else {
            $dadosRegistro["Nome_ong"] = campoTexto($nome);
            $dadosRegistro["Email"] = campoTexto($email);
            $dadosRegistro["Senha_Acesso"] = campoTexto($senha);
            $dadosRegistro["Endereco"] = campoTexto($endereco);
            $dadosRegistro["Numero"] = campoTexto($numero);
            $dadosRegistro["Bairro"] = campoTexto($bairro);
            $dadosRegistro["Cidade"] = campoTexto($cidade);
            $dadosRegistro["cep"] = campoTexto($cep);
            

            $conexao_bd->setINSERT($dadosRegistro, "ongs");

            if(!$conexao_bd->execINSERT()) {  
                echo "<h3>Erro na execução do comando INSERT</h3>";
            } else {
                echo "<h3>Cadastro efetuado com sucesso!</h3>";
                $_SESSION["NOME_USUARIO"] = $dadosRegistro["Nome_ong"];
                header('Location: index_log.php');
                exit();
            }
        }
        $conexao_bd->fecharConexao();
    } else {
        echo $mensagemErro;
    }
}