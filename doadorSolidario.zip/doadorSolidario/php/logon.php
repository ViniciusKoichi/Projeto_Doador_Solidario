<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/reset.css">
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/login.css">
    <title>Login</title>
</head>
<body>
    <div class="container">
        <div class="conteudo primeiro_conteudo">
            <div class="primeira_coluna">
                <h2>Bem vindo de volta!</h2>
                <p class="descricao">Para continuar conectado acesse sua conta!</p>
                <a class="btn btn_primary" href="login.php">Entrar</a>
            </div><!--Fim primeira_coluna-->
            <div class="segunda_coluna">
                <h2>Crie sua conta!</h2>
                <div class="social">
                    <ul class="social__lista">
                        <li class="social__item"><a href="#"><svg width="24" height="25" viewBox="0 0 64 123" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M17.9957 122.222V68.2353H0V45.7406H17.9957V27.7449C17.9957 9.15083 29.7694 0 46.357 0C54.3021 0 61.1315 0.593859 63.12 0.854797V20.2902L51.6162 20.2947C42.5959 20.2947 40.4904 24.5822 40.4904 30.8717V45.7406H62.985L58.4861 68.2353H40.4904L40.8503 122.222" fill="#3B5998"/>
                        </svg></a></li>
                        <li class="social__item"><a href="#"><svg width="24" height="25" viewBox="0 0 64 65" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M14.1722 26.2779C16.682 18.673 23.8288 13.2112 32.294 13.2112C36.8445 13.2112 40.9546 14.8259 44.184 17.4681L53.5786 8.07349C47.8538 3.0826 40.5142 0 32.294 0C19.5649 0 8.60567 7.26156 3.33702 17.8963L14.1722 26.2779Z" fill="#EA4335"/>
<path d="M43.1682 48.4748C40.2354 50.3686 36.5086 51.3768 32.294 51.3768C23.8612 51.3768 16.7367 45.9566 14.2012 38.3972L3.33022 46.6513C8.59232 57.3046 19.5513 64.5879 32.294 64.5879C40.1867 64.5879 47.7287 61.7821 53.377 56.5133L43.1682 48.4748Z" fill="#34A853"/>
<path d="M53.377 56.5133C59.2841 51.0032 63.12 42.7994 63.12 32.294C63.12 30.3857 62.8264 28.3306 62.386 26.4223H32.294V38.8995H49.6153C48.7606 43.0953 46.4664 46.3451 43.1682 48.4748L53.377 56.5133Z" fill="#4A90E2"/>
<path d="M14.2012 38.3972C13.559 36.4823 13.2112 34.4301 13.2112 32.294C13.2112 30.1902 13.5485 28.1679 14.1722 26.2779L3.33702 17.8963C1.17493 22.2302 0 27.1145 0 32.294C0 37.4598 1.19698 42.3325 3.33021 46.6513L14.2012 38.3972Z" fill="#FBBC05"/>
</svg>
</a></li>
                    </ul>
                </div><!--Fim social-->
                <p class="descricao">Ou utilize seu email para se registrar!</p>
                <form name="cadastraUsuario" action="" method="post" class="form">
                    <input type="text" name="nome" id="" placeholder="nome">
                    <input type="email" name="e-mail" id="" placeholder="e-mail">
                    <input type="password" name="senha" id="" placeholder="senha">
                    <button class="btn btn_primary" name="btnCriar" id="criar">Criar</button>
                    <?php 
                        require_once("cadastro_conta.php")
                    ?>
                </form>
                <a class="voltar" href="../php/index.php">Voltar</a>      
            </div><!--Fim segunda_coluna-->
        </div><!--Fim primeiro_conteudo-->
    </div>

</body>
</html>