<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <link rel="stylesheet" href="../css/reset.css">
        <link rel="stylesheet" href="../css/style.css" />
        <title>Doador Solidário</title>
    </head>
    <body>
        <script src="../js/main.js"></script>
        <?php
        require_once("efetuar_login_ong.php");
        require_once("efetuar_login.php");
        session_name('System_A');
        session_start();
        ?>
        <img class="back_img" src="../assets/header.jpg" alt="">
        <header class="header" id="header">
            <nav class="nav_bar" id="nav_bar">
                <div class="logo"><a href="#">Doador<span>Solidário</span></a></div>
                <ul class="menu__options">
                    <li><a href="#header">Home</a></li>
                    <li><a href="#about">Sobre</a></li>
                    <li><a href="#doar">Doe</a></li>
                    <li><a href="">Histórico</a></li>
                    <li><a href="login_ong.php">Sou Ong</a></li>
                </ul>
                <div class="login">
                    <a href="#"><?php echo $_SESSION["NOME_USUARIO"];?></a>
                    <a class="button" href="index.php">Sair 
                        <svg width="12" height="10" viewBox="0 0 12 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M0 5C0 4.81059 0.079009 4.62895 0.219646 4.49502C0.360282 4.36109 0.551026 4.28584 0.749916 4.28584H9.43845L6.21831 1.22068C6.07749 1.08658 5.99838 0.904705 5.99838 0.715059C5.99838 0.525414 6.07749 0.343536 6.21831 0.209436C6.35912 0.0753365 6.5501 0 6.74925 0C6.94839 0 7.13937 0.0753365 7.28019 0.209436L11.7797 4.49438C11.8495 4.56072 11.9049 4.63952 11.9427 4.72629C11.9805 4.81305 12 4.90606 12 5C12 5.09394 11.9805 5.18695 11.9427 5.27371C11.9049 5.36048 11.8495 5.43928 11.7797 5.50562L7.28019 9.79056C7.13937 9.92466 6.94839 10 6.74925 10C6.5501 10 6.35912 9.92466 6.21831 9.79056C6.07749 9.65646 5.99838 9.47459 5.99838 9.28494C5.99838 9.0953 6.07749 8.91342 6.21831 8.77932L9.43845 5.71416H0.749916C0.551026 5.71416 0.360282 5.63892 0.219646 5.50499C0.079009 5.37106 0 5.18941 0 5Z" fill="white"/>
                        </svg>
                    </a>
                    
                </div>
            </nav>
        </header>
        <main>
             <div class="home">
                <h5>Junte-se a nós</h5>
                <h1>Doador Solidário</h1>
                <h4>Com o Doador Solidário, sua doação de alimentos, roupas, brinquedos faz a diferença na vida de quem mais precisa. Faça a diferença no mundo ajude o próximo!</h4>
                <a href="" class="button">Doe Agora</a>
            </div>
            <section>
                <div class="cards">
                    <div class="card">
                        <svg width="79" height="78" viewBox="0 0 69 68" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M50.34 18.78L66.12 25.9527V63.2509L46.0364 54.6436M46.0364 54.6436L23.0836 63.2509M46.0364 54.6436V34.56M23.0836 63.2509L3 54.6436V17.3455L17.3455 23.0836M23.0836 63.2509V34.56M34.56 46.8188C34.56 46.8188 17.3455 33.1255 17.3455 20.2145C17.3455 9.45545 25.9527 3 34.56 3C43.1673 3 51.7745 9.45545 51.7745 20.2145C51.7745 33.1255 34.56 46.8188 34.56 46.8188ZM37.4291 20.2145C37.4291 18.6299 36.1447 17.3455 34.56 17.3455C32.9753 17.3455 31.6909 18.6299 31.6909 20.2145C31.6909 21.7992 32.9753 23.0836 34.56 23.0836C36.1447 23.0836 37.4291 21.7992 37.4291 20.2145Z" stroke="black" stroke-width="5.73818"/>
                        </svg>

                        <h3>Perto de você!</h3>
                        <hr>
                        <p>Busque por diversas ongs e escolha a mais adqueada pra você!</p>
                    </div>
                    <div class="card">
                        <svg width="79" height="78" viewBox="0 0 69 58" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M3 18.4931C3 5.86909 13.0418 3 18.78 3C25.9527 3 31.6909 8.73818 34.56 13.0418C37.4291 8.73818 43.1673 3 50.34 3C56.0782 3 66.12 5.86909 66.12 18.4931C66.12 37.4291 34.56 54.6436 34.56 54.6436C34.56 54.6436 3 37.4291 3 18.4931Z" stroke="black" stroke-width="5.73818"/>
                        </svg>
                        <h3>Compartilhe!</h3>
                        <hr>
                        <p>Espalhe o amor! Ajude milhares de pessoas e famílias!</p>
                    </div>
                    <div class="card">
                        <svg width="79" height="77" viewBox="0 0 69 67" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path d="M46.0364 43.1673C46.0364 39.9982 37.0446 37.4291 25.9527 37.4291M46.0364 43.1673C46.0364 46.3364 37.0446 48.9055 25.9527 48.9055C14.8608 48.9055 5.86909 46.3364 5.86909 43.1673M46.0364 43.1673V57.3313C46.0364 60.6006 37.0446 63.2509 25.9527 63.2509C14.8608 63.2509 5.86909 60.6006 5.86909 57.3313V43.1673M46.0364 43.1673C57.0064 43.1673 66.12 40.3352 66.12 37.4291V8.73818M25.9527 37.4291C14.8608 37.4291 5.86909 39.9982 5.86909 43.1673M25.9527 37.4291C13.2763 37.4291 3 34.597 3 31.6909V17.3455M25.9527 11.6073C13.2763 11.6073 3 14.1763 3 17.3455M3 17.3455C3 20.5146 13.2763 23.0836 25.9527 23.0836C25.9527 25.9897 35.2871 28.8218 46.2571 28.8218C57.2271 28.8218 66.12 25.9897 66.12 23.0836M66.12 8.73818C66.12 5.56907 57.2271 3 46.2571 3C35.2871 3 26.3941 5.56907 26.3941 8.73818M66.12 8.73818C66.12 11.9073 57.2271 14.4764 46.2571 14.4764C35.2871 14.4764 26.3941 11.9073 26.3941 8.73818M26.3941 8.73818V37.9054" stroke="black" stroke-width="5.73818"/>
                        </svg>
                        <h3>Nos Apoie!</h3>
                        <hr>
                        <p>Toda ajuda é bem vinda! Nos ajude a crescer!</p>
                    </div>
                </div>
            </section>
            <section class="about" id="about">
                <?php
                                        require_once("BancoDados.php");
                                        
                                        $conexao_bd = new BancoDados("localhost");
                                        
                                        if(!$conexao_bd->abrirConexao()) {
                                            echo "<p>Erro na conexão com o banco de dados!</br>" . $conexao_bd->getMensagemErro() . "</p>";
                                        }
                                            $conexao_bd->fecharConexao();
                                    ?>
                <img src="../assets/pexels-rodnae-productions-6647119.jpg" alt="">
                <div class="wrapper">
                    <svg width="95" height="8" viewBox="0 0 95 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <rect x="0.5" y="0.5" width="94" height="7" fill="#2DC071"/>
                    </svg>
                    <h2>Quem somos?</h2>
                    <p>Uma empresa que tem o principal objetivo conectar os doadores com quem mais precisa. Garantimos a segurança de seus dados e sua doação será entregue o mais rápido o possível pra quem realmente precisa.</p>
                </div>
            </section>
            <section class="doar" id="doar">
                <h1>Doe e ajude o próximo!</h1>
                <p>Você pode fazer a diferença! Doe para ong que preferir da forma que preferir!</p>
                <div class="form_doacao">
                    <form action="doacao.php" method="post">
                        <h4>Para qual ong gostaria de doar?</h4>
                        <?php
                            echo listaOngs();
                        ?><br>
                        <input class="btn" type="submit" name="btnConfirmar" value="Confirmar">
                        <input class="btn" type="reset" name="btnCancelar" value="Cancelar">
                    </form>
                </div>
                
            </section>
        </main>
        <footer></footer>
        
    </body>
</html>
