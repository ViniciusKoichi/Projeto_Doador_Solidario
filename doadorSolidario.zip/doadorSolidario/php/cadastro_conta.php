<?php
require_once("configuracao.php");
require_once("funcoes_diversas.php");
require_once("BancoDados.php");

error_reporting(E_ERROR | E_PARSE);

$nome = $_REQUEST["nome"];
$email = $_REQUEST["e-mail"];
$senha = $_REQUEST["senha"];
$erroDados = FALSE;
$mensagemErro = "";

if(trim($nome) == "" && trim($email) == "" && trim($senha) == "") {

} else {
        if(trim($nome) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Nome Obrigatório...</h3>";
    }

    if(trim($email) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>E-mail Obrigatório...</h3>";
    }

    if(trim($senha) == "") {
        $erroDados = TRUE;
        $mensagemErro .= "<h3>Senha Obrigatória...</h3>";
    }

    if(!$erroDados) {
        $conexao_bd = new BancoDados($servidorMySQL);
        if(!$conexao_bd->abrirConexao()) {
            echo "<h3>Erro na conexão com o banco de dados!<br/>" . $conexao_bd->getMensagemErro() . "</h3>";
        } else {
            $dadosRegistro["Nome_Usuario"] = campoTexto($nome);
            $dadosRegistro["Email"] = campoTexto($email);
            $dadosRegistro["Senha_Acesso"] = campoTexto($senha);


            $conexao_bd->setINSERT($dadosRegistro, "usuarios");

            if(!$conexao_bd->execINSERT()) {  
                echo "<h3>Erro na execução do comando INSERT</h3>";
            } else {
                echo "<h3>Cadastro efetuado com sucesso!</h3>";
                header('Location: ../php/index_log.php');
                exit();
            }
        }
        $conexao_bd->fecharConexao();
    } else {
        echo $mensagemErro;
    }
}
