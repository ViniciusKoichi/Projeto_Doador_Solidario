<?php
require_once("configuracao.php");
require_once("BancoDados.php");
require_once("funcoes_diversas.php");

error_reporting(E_ERROR | E_PARSE);

session_name('System_A');
session_start();

$_SESSION["USUARIO_LOGADO"] = 0;

if($_SESSION["USUARIO_LOGADO"] == 1) {
    echo "<h3>Usuario já logado no sistema...</h3>";
} else {
    $conexao_bd = new BancoDados($servidorMySQL);
    if(!$conexao_bd->abrirConexao()) {
        echo "<h2>não foi possível conectar com o banco de dados do site</h2><br>";
        echo $conexao_bd->getCodigoErro() . "->" . $conexao_bd->getMensagemErro();
    } else {
        if(($_REQUEST["Nome_ong"] != "") && ($_REQUEST["Senha_Acesso"] != "")) {
            $Nome_ong = $_REQUEST["Nome_ong"];
            $Senha_Acesso = $_REQUEST["Senha_Acesso"];
            $conexao_bd->setSELECT("Nome_ong, Senha_Acesso", "ongs");
            $conexao_bd->setWHERE(" Nome_ong = " . campoTexto($Nome_ong) . " AND Senha_Acesso = " . campoTexto($Senha_Acesso));

            if($conexao_bd->execSELECT()) {
                $numeroRegistros = $conexao_bd->getTotalRegistros();

                if($numeroRegistros == 1) {
                    $_SESSION["USUARIO_LOGADO"] = 1;
                    $_SESSION["NOME_USUARIO"] = $Nome_ong;
                    echo "<h3>Usuário logado com sucesso...</h3>";
                    header('Location: index_log.php');
                    exit();
                } else {
                    $_SESSION["USUARIO_LOGADO"] = 0;
                    $_SESSION["NOME_USUARIO"] = "";
                    echo "<h3>Usuário/senha inválidos...</h3>";
                }
            } else {
                echo "<h2>Erro na execução do comando SELECT...</h2>";
            }
        }
    }
    $conexao_bd->fecharConexao();
}