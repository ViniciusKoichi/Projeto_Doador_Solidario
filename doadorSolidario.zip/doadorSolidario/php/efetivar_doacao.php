<?php
require_once("configuracao.php");
require_once("BancoDados.php");
require_once("funcoes_diversas.php");

session_name('System_A');
session_start();

$tipo = $_REQUEST["tipos"];
$quantidade = $_REQUEST["quantidade"];
$usuario = $_SESSION["NOME_USUARIO"];
/*$usuario_id =*/
$erroDados = FALSE;
$mensagemErro = "";

if(trim($tipo) =="") {
    $erroDados = TRUE; 
    $mensagemErro .= "<h3>Nenhum tipo selecionado...</h3>";
}

if(!$erroDados) {
    $conexao_bd = new BancoDados($servidorMySQL);

    if(!$conexao_bd->abrirConexao()) {
        echo "<h3>Erro na conexão com o banco de dados!<br>" .$conexao_bd->getMensagemErro() . "</h3>";
    } else {

        $dadosRegistro["tipo"] = $tipo;
        $dadosRegistro["quantidade"] = $quantidade;
        $dadosRegistro["usuario"] = 8;
        $dadosRegistro["ong"] = 4;
        

        $conexao_bd->setINSERT($dadosRegistro, "doacoes");

        if(!$conexao_bd->execINSERT()) {  
            echo "<h3>Erro na execução do comando INSERT</h3>";
        } else {
            echo "<h3>Doação efetuada com sucesso!</h3>";
            
        }
    }
    $conexao_bd->fecharConexao();
    } else {
    echo $mensagemErro;
}

