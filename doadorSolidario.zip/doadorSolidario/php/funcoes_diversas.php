<?php

require_once 'configuracao.php';
require_once 'BancoDados.php';

    function DataInvertida($dataNormal)
    {
        $dia = substr($dataNormal, 0, 2);
        $mes = substr($dataNormal, 3, 2);
        $ano = substr($dataNormal, 6, 4);
        $DataInvertida = $ano . "/" . $mes . "/" . $dia;
        return $DataInvertida;
    }
    
    /*function Estados($ordemTabulacao)
    {
        global $servidorMySQL;
   
        $listaEstados = "<select name='Estado' size='1' tabindex=$ordemTabulacao>";
        
        $conexao_bd = new BancoDados("localhost");
        
        if ($conexao_bd->abrirConexao()) {
            $conexao_bd->setSELECT("UF, Estado", "estados");
            $conexao_bd->setORDER("Estado");
            
            if($conexao_bd->execSELECT()) {
                $numeroRegistros = $conexao_bd->getTotalRegistros();
                $dataSet = $conexao_bd->getDataSet();
                
                if($numeroRegistros > 0) {
                    while($registros = $dataSet->fetch_assoc()) {
                        $listaEstados .= "<option value='" . $registros["UF"] . "'>"
                                . $registros["Estado"] . "</option>";
                    }
                }
            }
        }
        $conexao_bd->fecharConexao();
        $listaEstados .= "</select>";
        return $listaEstados;
    }*/
    
    function soDigito($valor)
    {
        $tamanho = strlen($valor);
        $novoValor = "";
        
        for($contador = 0; $contador < $tamanho; $contador++) {
            $digito = $valor[$contador];
            
            if((ord($digito) >= 48) && (ord($digito) <= 57)) {
                $novoValor .= $digito;
            }
        }
        return trim($novoValor);
    }
    
    
    function campoTexto($valor) 
    {
        return "'" . $valor . "'";
    }

    function listaTipos() {
        $tipos = "<select name='tipos'>";

        $conexao_bd = new BancoDados($GLOBALS["servidorMySQL"]);

        if ($conexao_bd->abrirConexao()) {
            $conexao_bd->setSELECT("Codigo_tipo, tipo", "tipo_doacao"); 
            if($conexao_bd->execSELECT()) {
                $numeroRegistros = $conexao_bd->getTotalRegistros();
                $dataSet = $conexao_bd->getDataSet();                

                if($numeroRegistros > 0) {
                    while($registros = $dataSet->fetch_assoc()) {
                        $tipos .= "<option  value='" .$registros["Codigo_tipo"]. "'>" .$registros["tipo"]."</option>";
                    }
                }
            }
        }
        $conexao_bd->fecharConexao();
        $$tipos .= "</select>";
        return $tipos;
    }

    function listaOngs() {
        $ongs = "<select name='ongs'>";
    
        $conexao_bd = new BancoDados($GLOBALS["servidorMySQL"]);

        if ($conexao_bd->abrirConexao()) {
            $conexao_bd->setSELECT("Codigo_Ong, Nome_ong", "ongs"); 
            if($conexao_bd->execSELECT()) {
                $numeroRegistros = $conexao_bd->getTotalRegistros();
                $dataSet = $conexao_bd->getDataSet();                

                if($numeroRegistros > 0) {
                    while($registros = $dataSet->fetch_assoc()) {
                        $ongs .= "<option  value='" .$registros["Codigo_Ong"]. "'>" .$registros["Nome_ong"]."</option>";
                    }
                }
            }
        }
        $conexao_bd->fecharConexao();
        $ongs .= "</select>";
        return $ongs;
    }