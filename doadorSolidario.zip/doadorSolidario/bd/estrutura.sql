create database ong_solidaria;

CREATE TABLE `ongs` (
  `Codigo_Ong` smallint(6) NOT NULL AUTO_INCREMENT,
  `Nome_ong` varchar(50) NOT NULL,
  `Email` varchar(30) CHARACTER SET latin1 NOT NULL,
  `Senha_Acesso` varchar(10) CHARACTER SET latin1 NOT NULL,
  `Inscricao_Estadual` varchar(20) CHARACTER SET latin1 DEFAULT NULL,
  `Endereco` varchar(50) CHARACTER SET latin1 NOT NULL,
  `Numero` varchar(10) CHARACTER SET latin1 DEFAULT NULL,
  `Bairro` varchar(40) CHARACTER SET latin1 NOT NULL,
  `Cidade` varchar(40) CHARACTER SET latin1 NOT NULL,
  `UF` char(2) CHARACTER SET latin1 NULL,
  `Telefone` varchar(18) CHARACTER SET latin1 DEFAULT NULL,
  `cep` varchar(10) NOT NULL,
  PRIMARY KEY (`Codigo_Ong`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

CREATE TABLE `usuarios` (
  `Codigo_Usuario` int(11) NOT NULL AUTO_INCREMENT,
  `Nome_Usuario` varchar(20) CHARACTER SET latin1 NOT NULL,
  `Email` varchar(30) NOT NULL,
  `Senha_Acesso` varchar(10) CHARACTER SET latin1 NOT NULL,
  `Telefone` varchar(15) NULL,
  PRIMARY KEY (`Codigo_Usuario`),
  KEY `Nome_Usuario` (`Nome_Usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

CREATE TABLE `tipo_doacao` (
`Codigo_tipo` int NOT NULL auto_increment,
`tipo` varchar(15) NOT NULL,
PRIMARY KEY (`Codigo_tipo`),
KEY `tipo` (`tipo`)
);

CREATE TABLE `doacoes` (
`Codigo_doacao` int NOT NULL auto_increment,
`tipo` varchar(15) NOT NULL,
`quantidade` float NOT NULL,
`usuario` int(11) NOT NULL,
`ong` smallint(6) NOT NULL,
primary KEY (`Codigo_doacao`),
constraint `usuario_fk` foreign key (`usuario`) references `usuarios` (`Codigo_Usuario`),
constraint `ong_fk` foreign key (`ong`) references `ongs` (`Codigo_Ong`),
constraint `tipo_fk` foreign key (`tipo`) references `tipo_doacao` (`tipo`)
)

